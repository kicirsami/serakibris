
-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `greenhouse`
--

CREATE TABLE `greenhouse` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `site_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `greenhouse`
--

INSERT INTO `greenhouse` (`id`, `name`, `img`, `site_id`) VALUES
(30, 'Sera 1', '', '1');
