
-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `parent_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `fullname`, `phone`, `email`, `role_id`, `image_path`, `parent_user_id`) VALUES
(1, 'Admin', '$2b$10$6SY4j2gMx6CgXMctWiI8eu7QTcDxd7Ou.wwgrobAESYZGvgwDv0Dq', 'Admin', '05488505202', 'serakibris@outlook.com', 1, NULL, 1),
(3, 'görkem', '$2b$10$6I8XlSA.zcuxwmiGXDmoU.Xk1ssyzEAL2cBkIvAa6Zn/XBr0LH2Oy', 'Görkem Kurşun', '55555555555', 'test@gmail.com', 1, '1716254530296.jpg', 1),
(4, 'çalışan02', '$2b$10$hS0abaOk7fDSMIi34h1V.ebOCcb7ahdRLmfAPh2BRSqBOvRPngym6', 'Orhan Akın', '55555555555', 'test@gmail.com', 2, '1716254143416.png', 3),
(5, 'çalışan03', '$2b$10$06JhHYOstkwIe22K64d7GO2m.a5HskWosF/xEfI6/E.wtnXY7lesa', 'Serdar Gündeş', '55555555555', 'test@gmail.com', 2, '', 3),
(6, 'yönetici01', '$2b$10$KNaTUTqzIH5S29yg1h89ZuVhp5eC2VDzV4kr4H5Ys1582pbJuo.mS', 'Muzaffer Khan', '05488555555', 'test@gmail.com', 1, '1716254558698.jpg', 1),
(8, 'çalışan04', '$2b$10$vlShJbzw0y3W9T3coc0NEee0vow3HMQ2hpUEZ2DmU6/7.K50Hex.i', 'Sami Kıcır', '05488555555', 'test@gmail.com', 2, '', 6),
(9, 'yönetici02', '$2b$10$y8/HVtScsSR2M2KOP6.UVeBTd4lXmx0Yg14ZK8HVGPTsoxwKPPKay', 'Test Yönetici', '05488555555', 'test@gmail.com', 1, '', 1),
(10, 'yöneticiTest', '$2b$10$aJ89ixX41/4L8fK8..OMzu0fkf9X76g9tUPcZ3US7xYrhHo4DlHK.', 'Yönetici Test', '05488555555', 'test@gmail.com', 1, '', 3);
